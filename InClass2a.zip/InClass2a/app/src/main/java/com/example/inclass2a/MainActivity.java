package com.example.inclass2a;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText heightinfeet;
    private EditText heightininches;
    private EditText weight;
    private TextView top;
    private TextView bottom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("BMI Calculator");
        heightinfeet = (EditText) findViewById(R.id.editTextHeightInFeet);
        heightininches = (EditText) findViewById(R.id.editTextHeightInInches);
        weight = (EditText) findViewById(R.id.editTextWeight);
        top = (TextView) findViewById(R.id.textViewTop);
        bottom = (TextView) findViewById(R.id.textViewBottom);
    }
    public void calculateBMI(View v)
    {
         String heightInFeetStr = heightinfeet.getText().toString();
        String heightInInchesStr = heightininches.getText().toString();
        String weightStr = weight.getText().toString();
        
        Float weight = Float.parseFloat(weightStr);
        Float heightInFeet = Float.parseFloat(heightInFeetStr);
        Float heightInInches = Float.parseFloat(heightInInchesStr);
        Float height

        heightStr = (heightInFeet * 12) + heightInInches;
        if(heightStr != null && )
    }





}
